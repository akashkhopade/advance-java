package com.sarje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprBootMailAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprBootMailAppApplication.class, args);
	}

}
