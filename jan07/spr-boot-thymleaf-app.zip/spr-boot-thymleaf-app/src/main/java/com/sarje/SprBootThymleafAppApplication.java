package com.sarje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprBootThymleafAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprBootThymleafAppApplication.class, args);
	}

}
